<template>
	<view>
		<!-- 头部 -->
		<view class="head">
			<!-- 标题 -->
			<image class="title"
			src="@/static/index/Icon_SY_huanyingci.png"></image>
			<!-- 搜索 -->
			<view class="search">
				<image class="icon"
				src="/static/index/Icon_SY_sousuo_01.png"></image>
				<view class="split"></view>
				<text>搜索社群或书籍</text>
			</view>
			<!-- 轮播图 -->
			<swiper class="publicity" 
			indicator-dots=trun
			indicator-color=rgba(255,255,255,.7)
			indicator-active-color=#fff>
				<swiper-item v-for="i in 3">
					<image class="img"
					src="@/static/index/Img_TP_lunbotu_01.png"></image>
				</swiper-item>
			</swiper>	
			<!-- 遮挡 -->
			<view class="bottom"><view class="bot"></view></view>
		</view>
		<!-- 社群板块 -->
		<view class="community">
			<!-- 导航 -->
			<view class="navigator">
				<view style="display: flex;flex-direction: column;align-items: center;">
					<image src="/static/index/Icon_SY_jgq_paihangbang.png"></image>
					<text>排行榜</text>
				</view>
				<navigator url="/pages/index/mall">
					<view style="display: flex;flex-direction: column;align-items: center;">
						<image src="/static/index/Icon_SY_jgq_shangcheng.png"></image>
						<text>商城</text>
					</view>
				</navigator>
				<view style="display: flex;flex-direction: column;align-items: center;">
					<image src="/static/index/Icon_SY_jgq_zhuangzangdadian.png"></image>
					<text>装藏大典</text>
				</view>
				<view style="display: flex;flex-direction: column;align-items: center;">
					<image src="/static/index/Icon_SY_jgq_zaixiantingshu.png"></image>
					<text>在线听书</text>
				</view>
				<view style="display: flex;flex-direction: column;align-items: center;">
					<image src="/static/index/Icon_SY_jgq_dangjianlingdao.png"></image>
					<text>党建引领</text>
				</view>
			</view>
			<!-- 标题 -->
			<image class="title"
			src="@/static/index/Icon_SY_dushushequn.png"></image>
			<!-- 社群 -->
			<view class="com">
				<image src="@/static/index/Img_dssq_huaxueshe.png"></image>
				<image src="@/static/index/Img_dssq_gufajianshenshe.png"></image>
				<image src="@/static/index/Img_dssq_weilaijiaoyushe.png"></image>
				<image src="@/static/index/Img_dssq_changlaoyuanshequn.png"></image>
				<image src="@/static/index/Img_dssq_dajiankangshequn.png"></image>
				<image src="@/static/index/Img_dssq_yaoshanshequn.png"></image>
				<image src="@/static/index/Img_dssq_zhongyaoshequn.png"></image>
				<image src="@/static/index/Img_dssq_qitashequn.png"></image>
			</view>
		</view>
		<!-- 活动板块 -->
		<view class="event">
			<!-- 标题 -->
			<view>
				<image src="@/static/index/Icon_SY_huodongtuijian.png"
				 class="title"></image>
				 <view>
					<text class="eventt">更多活动</text>
					<image class="eventi" src="@/static/index/icon_tongyong_jinru01.png"></image>
				 </view>
			</view>
			<!-- 内容 -->
			<view style="position: relative;top: 88rpx;">
				<view style="position: relative;">
					<image src="/static/logo.png"></image>
					<text class="pro">以书为媒，以茶会友丨华学社250801期读书分享会精彩回顾</text>
					<text class="info">华学社·世外茶屿读书社·公益沙龙</text>
				</view>
				<!-- 分割线 -->
				<view class="hr"></view>
				<view style="position: relative;">
					<image src="/static/logo.png"></image>
					<text class="pro">小兴安岭7天6夜纵贯东北夏令营，从盛京烟火到临海深处</text>
					<text class="info">华学社·东北夏令营</text>
				</view>
			</view>
		</view>
		<!-- 打卡 -->
		<view class="clock">
			<!-- 按钮 -->
			<view class="buttom">
				<text class="title">开始读书打卡</text>
				<text class="info">(不积跬步无以至千里，不积小流无以成江海)</text>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		onLoad() {
			
		},
		methods: {

		}
	}
</script>

<style lang="scss">
	page{
		background-color: #F2F4F6;
		padding-bottom: 300rpx;
	}
	.head{
		position: relative;
		height: 538rpx;
		background: #0D7CFF;
		.title{
			width: 238rpx;
			height: 33rpx;
			position: absolute;
			top: 115rpx;
			left: 32rpx;
		}
		.search{
			width: 690rpx;
			height: 72rpx;
			background: #C7E1FF;
			border-radius: 20rpx;
			position: absolute;
			top: 186rpx;
			left: 30rpx;
			.icon{
				width: 36rpx;
				height: 36rpx;
				position: absolute;
				top: 18rpx;
				left: 27rpx;
			}
			.split{
				width: 2rpx;
				height: 24rpx;
				background: #789CC6;
				border-radius: 1rpx;
				position: absolute;
				top: 24rpx;
				left: 88rpx;
			}
			text{
				width: 201rpx;
				height: 26rpx;
				font-family: PingFang SC;
				font-weight: 500;
				font-size: 28rpx;
				color: #789CC6;
				line-height: 28rpx;
				position: absolute;
				top: 23rpx;
				left: 117rpx;
			}
		}
		.publicity{
			width: 690rpx;
			height: 230rpx;
			position: absolute;
			top: 280rpx;
			left: 30rpx;
			.img{
				width: 100%;
				height: 100%;
				object-fit: cover; /* 关键属性：保持比例填充容器 */
				object-position: center; /* 图片居中 */
			}
		}
		.bottom{
			position: absolute;
			bottom: 0;
			filter: drop-shadow(0 -1rpx 16rpx rgba(15,79,154,.3));
			.bot{
				width: 750rpx;
				height: 80rpx;
				background-color: #FFFFFF;
				clip-path: polygon(0% 0%, 0% 100%, 100% 100%, 100% 0%, 
				90% 20%,
				80% 39%,
				65% 50%,
				50% 60%,
				35% 50%,
				20% 39%,
				10% 20%);
			}
		}
	}
	.community{
		width: 750rpx;
		height: 1036rpx;
		background: #FFFFFF;
		position: relative;
		.navigator{
			width: 100%;
			background: #FFFFFF;
			position: absolute;
			top: -7rpx;
			display: flex;
			justify-content: space-evenly;
			image{
				width: 92rpx;
				height: 92rpx;
			}
			text{
				font-family: PingFang SC;
				font-weight: 500;
				font-size: 28rpx;
				color: #333333;
				line-height: 28rpx;
			}
		}
		.title{
			width: 132rpx;
			height: 30rpx;
			position: absolute;
			top: 167rpx;
			left: 32rpx;
		}
		.com{
			position: absolute;
			top: 225rpx;
			width: 100%;
			display: flex;
			flex-wrap: wrap;
			justify-content: space-evenly;
			gap: 22rpx 0; 
			image{
				width: 334rpx;
				height: 180rpx;
			}
		}
	}
	.event{
		width: 100%;
		height: 486rpx;
		position: relative;
		background: #FFFFFF;
		margin-top: 22rpx;
		.title{
			position: absolute;
			top: 30rpx;
			left: 31rpx;
			width: 133rpx;
			height: 30rpx;
		}
		.eventt{
			font-family: PingFang SC;
			font-weight: 500;
			font-size: 26rpx;
			color: #9BA2AF;
			line-height: 28rpx;
			position: absolute;
			top: 34rpx;
			right: 60rpx;
		}
		.eventi{
			width: 12rpx;
			height: 22rpx;
			position: absolute;
			left: 708rpx;
			top: 36rpx;
		}
		image{
			height: 160rpx;
			width: 240rpx;
			position: relative;
			left: 30rpx;
		}
		.pro{
			position: absolute;
			top: 16rpx;
			left: 297rpx;
			width: 411rpx;
			height: 71rpx;
			font-family: PingFang SC;
			font-weight: 500;
			font-size: 30rpx;
			color: #111111;
			line-height: 42rpx;
		}
		.info{
			position: absolute;
			top: 119rpx;
			left: 297rpx;
			width: 411rpx;
			height: 25rpx;
			font-family: PingFang SC;
			font-weight: 500;
			font-size: 26rpx;
			color: #AFAFAF;
			line-height: 42rpx;
		}
		.hr{
			width: 690rpx;
			height: 2rpx;
			background: #EEEEEE;
			margin: 24rpx 30rpx;
		}
	}
	.clock{
		width: 750rpx;
		height: 188rpx;
		background: #FFFFFF;
		box-shadow: 0rpx -1rpx 8rpx 0rpx rgba(169,169,169,0.3);
		border-radius: 60rpx 60rpx 0rpx 0rpx;
		display: flex;
		justify-content: center;
		align-items: center;
		position: fixed;
		bottom: 0;
		z-index: 1;
		.buttom{
			width: 670rpx;
			height: 108rpx;
			background: linear-gradient(90deg, #6EB1FF 0%, #0D7CFF 100%);
			box-shadow: 0rpx 10rpx 20rpx 0rpx rgba(13,124,255,0.35);
			border-radius: 54rpx;
			display: flex;
			flex-direction: column;
			justify-content: space-evenly;
			align-items: center;
			.title{
				font-family: PingFang SC;
				font-weight: bold;
				font-size: 32rpx;
				color: #FFFFFF;
				line-height: 28rpx;
			}
			.info{
				font-family: PingFang SC;
				font-weight: 500;
				font-size: 22rpx;
				color: #FFFFFF;
				line-height: 28rpx;
			}
		}
	}
</style>
